Documentation is included in the app under the Setup Instructions dashboard.

You can also visit the Splunkbase page for the app:
https://splunkbase.splunk.com/app/3472/#/details