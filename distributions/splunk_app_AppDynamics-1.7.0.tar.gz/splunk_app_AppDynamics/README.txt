Splunk App for AppDynamics

Documentation can be found here: https://splunkbase.splunk.com/app/3472/#/details

Copyright (C) 2005-2018 Splunk Inc. All Rights Reserved. 

